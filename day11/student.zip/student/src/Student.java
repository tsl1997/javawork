/**这是一个学生类*/
public class Student {
	/**姓名*/
	public String name;
	/**成绩*/
	public int score;
	/**打印自我介绍*/
	public void showInfo(){
		System.out.println(name+"的成绩是："+score);
	}

}
