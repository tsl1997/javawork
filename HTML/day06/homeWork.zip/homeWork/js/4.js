//点击选中的添加到右边
document.getElementById("left1").onclick=function(){
    let arrCheckBox=document.getElementsByName("subject");//获取所有的subject标签
    

}